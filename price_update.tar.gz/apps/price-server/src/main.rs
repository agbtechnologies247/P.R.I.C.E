use axum::{
    routing::{get, post},
    Json, Router, Extension,
    response::{Html, IntoResponse},
};
use std::net::SocketAddr;
use std::sync::Arc;
use tracing::{info, Level};
use tracing_subscriber::FmtSubscriber;
use dotenvy::dotenv;

use price_broker::{Broker, PaperBroker, FyersClient, OrderRequest, Side};
use price_timeseries::TimescaleClient;

struct AppState {
    broker: Arc<price_broker::HybridBroker>,
    python_broker_url: String,
    db: TimescaleClient,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Initialize logging
    dotenv().ok();
    let subscriber = FmtSubscriber::builder()
        .with_max_level(Level::INFO)
        .finish();
    tracing::subscriber::set_global_default(subscriber)?;

    let python_broker_url = std::env::var("PYTHON_BROKER_URL")
        .unwrap_or_else(|_| "http://127.0.0.1:8001".to_string());

    // 2. Setup Hybrid broker client (executing both Live & Paper)
    let broker = Arc::new(price_broker::HybridBroker::new(&python_broker_url, 10000.0));

    let db_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "postgres://postgres:postgres@127.0.0.1:5433/price".to_string());
    let db = TimescaleClient::new(&db_url).await?;
    db.init_db().await?;

    let state = Arc::new(AppState {
        broker,
        python_broker_url,
        db,
    });

    // 3. Build routes
    let app = Router::new()
        .route("/", get(index_handler))
        .route("/health", get(health_handler))
        .route("/portfolio", get(portfolio_handler))
        .route("/orders", get(orders_handler))
        .route("/trades", get(trades_handler))
        .route("/order", post(place_order_handler))
        .route("/broker/auth_url", get(auth_url_handler))
        .route("/broker/login_token", post(login_token_handler))
        .route("/database/stats", get(db_stats_handler))
        .route("/metrics", get(metrics_handler))
        .layer(Extension(state));

    // 4. Run server
    let port = std::env::var("PORT")
        .unwrap_or_else(|_| "8000".to_string())
        .parse::<u16>()?;
    let addr = SocketAddr::from(([127, 0, 0, 1], port));
    let listener = tokio::net::TcpListener::bind(addr).await?;
    info!("PRICE REST server running at http://{}", addr);

    axum::serve(listener, app).await?;
    Ok(())
}

async fn index_handler() -> Html<&'static str> {
    Html(r##"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRICE Monitoring Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Space+Grotesk:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #0b0f19;
            --card-bg: rgba(20, 26, 46, 0.6);
            --border-color: rgba(255, 255, 255, 0.08);
            --primary: #6366f1;
            --primary-gradient: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --text-main: #f3f4f6;
            --text-muted: #9ca3af;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Outfit', sans-serif;
            min-height: 100vh;
            padding: 2rem;
            background-image: radial-gradient(circle at 10% 20%, rgba(99, 102, 241, 0.05) 0%, transparent 40%),
                              radial-gradient(circle at 90% 80%, rgba(168, 85, 247, 0.05) 0%, transparent 40%);
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1.5rem;
        }

        h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 2rem;
            font-weight: 700;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .status-badge {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
            padding: 0.4rem 1rem;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            background-color: var(--success);
            border-radius: 50%;
            display: inline-block;
            box-shadow: 0 0 10px var(--success);
        }

        .grid-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        @media (max-width: 1024px) {
            .grid-container {
                grid-template-columns: 1fr;
            }
        }

        .card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            backdrop-filter: blur(16px);
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
        }

        .card-title {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 1.25rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            padding-bottom: 0.75rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .metric-card {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.04);
            border-radius: 12px;
            padding: 1.25rem;
            text-align: center;
        }

        .metric-label {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
        }

        .metric-value {
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--text-main);
        }

        .metric-value.highlight {
            color: var(--primary);
        }

        .btn {
            background: var(--primary-gradient);
            border: none;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: none;
        }

        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-group label {
            display: block;
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
        }

        .input-text {
            width: 100%;
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 0.75rem;
            color: white;
            font-family: inherit;
            margin-bottom: 1rem;
        }

        .input-text:focus {
            outline: none;
            border-color: var(--primary);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            margin-top: 0.5rem;
        }

        th {
            color: var(--text-muted);
            font-weight: 600;
            font-size: 0.85rem;
            padding: 0.75rem 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            font-size: 0.9rem;
        }

        .pnl-green {
            color: var(--success);
            font-weight: 600;
        }

        .pnl-red {
            color: var(--danger);
            font-weight: 600;
        }

        .status-unconfigured {
            color: var(--warning);
            border-color: var(--warning);
            background: rgba(245, 158, 11, 0.1);
        }

        .status-unconfigured .status-dot {
            background-color: var(--warning);
            box-shadow: 0 0 10px var(--warning);
        }
    </style>
</head>
<body>

    <header>
        <div>
            <h1>P.R.I.C.E</h1>
            <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem;">Predictive Risk Intelligence & Capital Engine</p>
        </div>
        <div class="status-badge" id="platform-status-badge">
            <span class="status-dot"></span>
            <span id="platform-status-text">Live Monitoring</span>
        </div>
    </header>

    <div class="grid-container">
        <!-- Main Column -->
        <div>
            <div class="card">
                <div class="card-title">Portfolio & Account Balance (Dual Engines)</div>
                
                <h3 style="font-size: 0.85rem; color: var(--success); margin-bottom: 0.75rem; letter-spacing: 0.05em;">📈 LIVE FYERS ACCOUNT</h3>
                <div class="metrics-grid" style="margin-bottom: 1.5rem;">
                    <div class="metric-card" style="padding: 1rem;">
                        <div class="metric-label">Total Capital Limit</div>
                        <div class="metric-value highlight" id="live-val-limit">₹0.00</div>
                    </div>
                    <div class="metric-card" style="padding: 1rem;">
                        <div class="metric-label">Utilized Margin</div>
                        <div class="metric-value" id="live-val-utilized">₹0.00</div>
                    </div>
                    <div class="metric-card" style="padding: 1rem;">
                        <div class="metric-label">Available Balance</div>
                        <div class="metric-value" id="live-val-available">₹0.00</div>
                    </div>
                </div>

                <h3 style="font-size: 0.85rem; color: var(--primary); margin-bottom: 0.75rem; letter-spacing: 0.05em;">🤖 PAPER TRADING ACCOUNT</h3>
                <div class="metrics-grid">
                    <div class="metric-card" style="padding: 1rem;">
                        <div class="metric-label">Total Capital Limit</div>
                        <div class="metric-value highlight" id="paper-val-limit">₹0.00</div>
                    </div>
                    <div class="metric-card" style="padding: 1rem;">
                        <div class="metric-label">Utilized Margin</div>
                        <div class="metric-value" id="paper-val-utilized">₹0.00</div>
                    </div>
                    <div class="metric-card" style="padding: 1rem;">
                        <div class="metric-label">Available Balance</div>
                        <div class="metric-value" id="paper-val-available">₹0.00</div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-title">Active Net Positions</div>
                <table id="positions-table">
                    <thead>
                        <tr>
                            <th>Symbol</th>
                            <th>Side</th>
                            <th>Buy Qty</th>
                            <th>Avg Price</th>
                            <th>LTP</th>
                            <th>PnL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="6" style="text-align: center; color: var(--text-muted);">No active positions found</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="card">
                <div class="card-title">Recent Order Log</div>
                <table id="orders-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Symbol</th>
                            <th>Side</th>
                            <th>Qty</th>
                            <th>Avg Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="6" style="text-align: center; color: var(--text-muted);">No recent orders found</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Sidebar / Auth Console -->
        <div>
            <div class="card">
                <div class="card-title">TimescaleDB Ingestion Stats</div>
                <div class="metrics-grid" style="grid-template-columns: 1fr; margin-bottom: 0.75rem;">
                    <div class="metric-card" style="padding: 0.75rem;">
                        <div class="metric-label" style="margin-bottom: 0.25rem;">Total Candles Collected</div>
                        <div class="metric-value highlight" id="db-total-candles" style="font-size: 2rem;">0</div>
                    </div>
                </div>
                <div style="max-height: 250px; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 8px; padding: 0.5rem; background: rgba(0,0,0,0.1);">
                    <table id="db-symbols-table">
                        <thead>
                            <tr>
                                <th style="padding: 0.4rem;">Symbol</th>
                                <th style="padding: 0.4rem; text-align: right;">Candle Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="2" style="text-align: center; color: var(--text-muted); padding: 0.5rem;">No synced data</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-title">Fyers API Activation</div>
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1.5rem; line-height: 1.4;">
                    Your bridge is currently running in live-only mode. Use this console to complete user authorization and exchange your authentication code for a persistent session token.
                </p>
                
                <div class="form-group" style="text-align: center; margin-bottom: 1.5rem;">
                    <a href="#" target="_blank" class="btn" id="fyers-login-btn">1. Authorize App on Fyers</a>
                </div>

                <div class="form-group">
                    <label for="auth-code-input">2. Paste Auth Code from Redirect Link</label>
                    <input type="text" id="auth-code-input" class="input-text" placeholder="e.g. eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...">
                </div>

                <button class="btn btn-secondary" style="width: 100%;" id="activate-token-btn">3. Generate & Save Token</button>
                <div id="activation-message" style="margin-top: 1rem; font-size: 0.85rem; font-weight: 600; text-align: center;"></div>
            </div>
        </div>
    </div>

    <script>
        // Fetch Auth URL on load
        async function fetchAuthUrl() {
            try {
                const response = await fetch('/broker/auth_url');
                const data = await response.json();
                if (data.status === 'success' && data.auth_url) {
                    const loginBtn = document.getElementById('fyers-login-btn');
                    loginBtn.href = data.auth_url;
                }
            } catch (e) {
                console.error("Failed to load auth URL: ", e);
            }
        }

        // Fetch Health & Broker Status
        async function checkHealth() {
            try {
                const response = await fetch('/health');
                const data = await response.json();
                const badge = document.getElementById('platform-status-badge');
                const text = document.getElementById('platform-status-text');
                
                if (data.broker_connection === 'connected') {
                    badge.classList.remove('status-unconfigured');
                    text.textContent = 'Live System Active';
                } else {
                    badge.classList.add('status-unconfigured');
                    text.textContent = 'Broker Activation Pending';
                }
            } catch (e) {
                console.error("Health query failed: ", e);
            }
        }

        // Fetch Portfolio and balance
        async function fetchPortfolio() {
            try {
                const response = await fetch('/portfolio');
                const data = await response.json();
                
                if (data.live_funds) {
                    document.getElementById('live-val-limit').textContent = `₹${data.live_funds.limit_amount.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
                    document.getElementById('live-val-utilized').textContent = `₹${data.live_funds.utilised_balance.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
                    document.getElementById('live-val-available').textContent = `₹${data.live_funds.available_balance.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
                }
                if (data.paper_funds) {
                    document.getElementById('paper-val-limit').textContent = `₹${data.paper_funds.limit_amount.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
                    document.getElementById('paper-val-utilized').textContent = `₹${data.paper_funds.utilised_balance.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
                    document.getElementById('paper-val-available').textContent = `₹${data.paper_funds.available_balance.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
                }

                const posTableBody = document.querySelector('#positions-table tbody');
                if (data.positions && data.positions.length > 0) {
                    posTableBody.innerHTML = '';
                    data.positions.forEach(p => {
                        const row = document.createElement('tr');
                        const pnlClass = p.pnl >= 0 ? 'pnl-green' : 'pnl-red';
                        row.innerHTML = `
                            <td><strong>${p.symbol}</strong></td>
                            <td>${p.side === 1 ? 'BUY' : 'SELL'}</td>
                            <td>${p.buy_qty || p.sell_qty}</td>
                            <td>₹${p.avg_price.toFixed(2)}</td>
                            <td>₹${p.current_price.toFixed(2)}</td>
                            <td class="${pnlClass}">₹${p.pnl.toFixed(2)}</td>
                        `;
                        posTableBody.appendChild(row);
                    });
                } else {
                    posTableBody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No active positions found</td></tr>`;
                }
            } catch (e) {
                console.error("Failed to fetch portfolio: ", e);
            }
        }

        // Fetch Order Log
        async function fetchOrders() {
            try {
                const response = await fetch('/orders');
                const data = await response.json();
                const ordTableBody = document.querySelector('#orders-table tbody');
                
                if (data.orders && data.orders.length > 0) {
                    ordTableBody.innerHTML = '';
                    data.orders.forEach(o => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td><code>${o.id.substring(0, 8)}...</code></td>
                            <td><strong>${o.symbol}</strong></td>
                            <td>${o.side === 1 ? 'BUY' : 'SELL'}</td>
                            <td>${o.qty}</td>
                            <td>₹${o.avg_price.toFixed(2)}</td>
                            <td><span style="font-weight:600; color: ${o.status === 'FILLED' ? 'var(--success)' : 'var(--text-muted)'}">${o.status}</span></td>
                        `;
                        ordTableBody.appendChild(row);
                    });
                } else {
                    ordTableBody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No recent orders found</td></tr>`;
                }
            } catch (e) {
                console.error("Failed to fetch orders: ", e);
            }
        }

        // Handle Activation Click
        document.getElementById('activate-token-btn').addEventListener('click', async () => {
            const input = document.getElementById('auth-code-input').value.trim();
            const msg = document.getElementById('activation-message');
            msg.textContent = '';
            
            if (!input) {
                msg.textContent = 'Please paste the authorization code first.';
                msg.style.color = 'var(--danger)';
                return;
            }

            // Extract auth code from redirect URL if full URL is pasted
            let authCode = input;
            if (input.includes('auth_code=')) {
                const urlParams = new URLSearchParams(input.split('?')[1]);
                authCode = urlParams.get('auth_code') || input;
            }

            msg.textContent = 'Authenticating with Fyers API...';
            msg.style.color = 'var(--warning)';

            try {
                const response = await fetch('/broker/login_token', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ auth_code: authCode })
                });
                
                const data = await response.json();
                if (response.ok && data.status === 'success') {
                    msg.textContent = 'Fyers Broker activated successfully!';
                    msg.style.color = 'var(--success)';
                    // Reload health and balance after successful activation
                    setTimeout(() => {
                        checkHealth();
                        fetchPortfolio();
                        fetchOrders();
                    }, 1000);
                } else {
                    msg.textContent = `Activation Failed: ${data.detail || 'check parameters'}`;
                    msg.style.color = 'var(--danger)';
                }
            } catch (e) {
                msg.textContent = `Request error: ${e.message}`;
                msg.style.color = 'var(--danger)';
            }
        });

        // Fetch Database Stats
        async function fetchDbStats() {
            try {
                const response = await fetch('/database/stats');
                const data = await response.json();
                if (data.status === 'success') {
                    document.getElementById('db-total-candles').textContent = data.total_candles.toLocaleString('en-IN');
                    
                    const symTableBody = document.querySelector('#db-symbols-table tbody');
                    if (data.symbols && data.symbols.length > 0) {
                        symTableBody.innerHTML = '';
                        data.symbols.forEach(s => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td style="padding: 0.4rem;"><strong>${s.symbol}</strong></td>
                                <td style="padding: 0.4rem; text-align: right;">${s.count.toLocaleString('en-IN')}</td>
                            `;
                            symTableBody.appendChild(row);
                        });
                    } else {
                        symTableBody.innerHTML = `<tr><td colspan="2" style="text-align: center; color: var(--text-muted); padding: 0.5rem;">No synced data</td></tr>`;
                    }
                }
            } catch (e) {
                console.error("Failed to fetch DB stats: ", e);
            }
        }

        // Initialize and poll status
        fetchAuthUrl();
        checkHealth();
        fetchPortfolio();
        fetchOrders();
        fetchDbStats();
        
        setInterval(() => {
            fetchPortfolio();
            fetchOrders();
            fetchDbStats();
        }, 5000);
    </script>
</body>
</html>
"##)
}

async fn health_handler(Extension(state): Extension<Arc<AppState>>) -> Json<serde_json::Value> {
    let broker_ok = state.broker.profile().await.is_ok();
    Json(serde_json::json!({
        "status": "healthy",
        "broker_connection": if broker_ok { "connected" } else { "offline_simulated" },
        "system": "PRICE Predictive Risk Intelligence & Capital Engine",
        "version": "1.0.0"
    }))
}

async fn portfolio_handler(Extension(state): Extension<Arc<AppState>>) -> Json<serde_json::Value> {
    let live_funds = state.broker.live.funds().await.ok();
    let paper_funds = state.broker.paper.funds().await.ok();
    let positions = state.broker.positions().await.unwrap_or_default();
    let holdings = state.broker.holdings().await.unwrap_or_default();
    
    Json(serde_json::json!({
        "live_funds": live_funds,
        "paper_funds": paper_funds,
        "positions": positions,
        "holdings": holdings
    }))
}

async fn orders_handler(Extension(state): Extension<Arc<AppState>>) -> Json<serde_json::Value> {
    let orders = state.broker.orderbook().await.unwrap_or_default();
    Json(serde_json::json!({
        "orders": orders
    }))
}

async fn trades_handler(Extension(state): Extension<Arc<AppState>>) -> Json<serde_json::Value> {
    let trades = state.broker.trades().await.unwrap_or_default();
    Json(serde_json::json!({
        "trades": trades
    }))
}

#[derive(serde::Deserialize)]
struct ManualOrder {
    symbol: String,
    qty: i32,
    side: String, // "BUY" or "SELL"
    limit_price: f64,
}

async fn place_order_handler(
    Extension(state): Extension<Arc<AppState>>,
    Json(payload): Json<ManualOrder>,
) -> Json<serde_json::Value> {
    let side = if payload.side.to_uppercase() == "BUY" { Side::Buy } else { Side::Sell };
    let req = OrderRequest {
        symbol: payload.symbol,
        qty: payload.qty,
        r#type: 1, // Limit order
        side,
        limit_price: payload.limit_price,
        stop_price: 0.0,
    };
    
    match state.broker.place_order(req).await {
        Ok(resp) => Json(serde_json::json!({
            "status": "success",
            "order_id": resp.order_id,
            "message": resp.message
        })),
        Err(e) => Json(serde_json::json!({
            "status": "error",
            "message": e.to_string()
        })),
    }
}

async fn auth_url_handler(
    Extension(state): Extension<Arc<AppState>>,
) -> impl axum::response::IntoResponse {
    let client = reqwest::Client::new();
    match client.get(format!("{}/auth_url", state.python_broker_url)).send().await {
        Ok(res) => {
            let status = axum::http::StatusCode::from_u16(res.status().as_u16())
                .unwrap_or(axum::http::StatusCode::INTERNAL_SERVER_ERROR);
            let body = res.json::<serde_json::Value>().await.unwrap_or_else(|_| {
                serde_json::json!({"status": "error", "detail": "Failed to parse Python response"})
            });
            (status, Json(body)).into_response()
        }
        Err(e) => {
            (
                axum::http::StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({"status": "error", "detail": e.to_string()})),
            ).into_response()
        }
    }
}

#[derive(serde::Deserialize, serde::Serialize)]
struct LoginTokenRequest {
    auth_code: String,
}

async fn login_token_handler(
    Extension(state): Extension<Arc<AppState>>,
    Json(payload): Json<LoginTokenRequest>,
) -> impl axum::response::IntoResponse {
    let client = reqwest::Client::new();
    match client.post(format!("{}/login_token", state.python_broker_url))
        .json(&payload)
        .send()
        .await
    {
        Ok(res) => {
            let status = axum::http::StatusCode::from_u16(res.status().as_u16())
                .unwrap_or(axum::http::StatusCode::INTERNAL_SERVER_ERROR);
            let body = res.json::<serde_json::Value>().await.unwrap_or_else(|_| {
                serde_json::json!({"status": "error", "detail": "Failed to parse Python response"})
            });
            (status, Json(body)).into_response()
        }
        Err(e) => {
            (
                axum::http::StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({"status": "error", "detail": e.to_string()})),
            ).into_response()
        }
    }
}

async fn metrics_handler(Extension(state): Extension<Arc<AppState>>) -> impl IntoResponse {
    let mut body = String::new();

    // 1. Fetch funds metrics
    if let Ok(funds) = state.broker.funds().await {
        body.push_str("# HELP price_portfolio_balance_rupees Total available portfolio balance in rupees\n");
        body.push_str("# TYPE price_portfolio_balance_rupees gauge\n");
        body.push_str(&format!("price_portfolio_balance_rupees {:.2}\n", funds.available_balance));

        body.push_str("# HELP price_portfolio_utilized_margin_rupees Total utilized margin in rupees\n");
        body.push_str("# TYPE price_portfolio_utilized_margin_rupees gauge\n");
        body.push_str(&format!("price_portfolio_utilized_margin_rupees {:.2}\n", funds.utilised_balance));

        body.push_str("# HELP price_portfolio_limit_amount_rupees Total limit amount in rupees\n");
        body.push_str("# TYPE price_portfolio_limit_amount_rupees gauge\n");
        body.push_str(&format!("price_portfolio_limit_amount_rupees {:.2}\n", funds.limit_amount));
    }

    // 2. Fetch position metrics
    if let Ok(positions) = state.broker.positions().await {
        body.push_str("# HELP price_open_positions_count Total count of open positions\n");
        body.push_str("# TYPE price_open_positions_count gauge\n");
        body.push_str(&format!("price_open_positions_count {}\n", positions.len()));
        
        let mut total_pnl = 0.0;
        for p in &positions {
            total_pnl += p.pnl;
        }
        body.push_str("# HELP price_open_positions_pnl_rupees Total unrealized PnL of open positions\n");
        body.push_str("# TYPE price_open_positions_pnl_rupees gauge\n");
        body.push_str(&format!("price_open_positions_pnl_rupees {:.2}\n", total_pnl));
    }

    // 3. Fetch orders & trades metrics
    if let Ok(orders) = state.broker.orderbook().await {
        body.push_str("# HELP price_orders_count Total count of orders in the orderbook\n");
        body.push_str("# TYPE price_orders_count counter\n");
        body.push_str(&format!("price_orders_count {}\n", orders.len()));
    }

    if let Ok(trades) = state.broker.trades().await {
        body.push_str("# HELP price_trades_count Total count of executed trades in the tradebook\n");
        body.push_str("# TYPE price_trades_count counter\n");
        body.push_str(&format!("price_trades_count {}\n", trades.len()));
    }

    axum::response::Response::builder()
        .header("content-type", "text/plain; version=0.0.4; charset=utf-8")
        .body(axum::body::Body::from(body))
        .unwrap()
}

async fn db_stats_handler(Extension(state): Extension<Arc<AppState>>) -> impl IntoResponse {
    match state.db.get_db_stats().await {
        Ok(stats) => {
            let total_candles: i64 = stats.iter().map(|(_, count)| count).sum();
            let symbols_list: Vec<serde_json::Value> = stats
                .into_iter()
                .map(|(symbol, count)| {
                    serde_json::json!({
                        "symbol": symbol,
                        "count": count
                    })
                })
                .collect();
            
            (
                axum::http::StatusCode::OK,
                Json(serde_json::json!({
                    "status": "success",
                    "total_candles": total_candles,
                    "symbols": symbols_list
                })),
            ).into_response()
        }
        Err(e) => {
            (
                axum::http::StatusCode::INTERNAL_SERVER_ERROR,
                Json(serde_json::json!({"status": "error", "detail": e.to_string()})),
            ).into_response()
        }
    }
}

